#!/usr/bin/env perl

#########################################################################
#                                                                       #
# Copyright and Intellectual Property Right Notice:                     #
#                                                                       #
# All contents of this Source Code are: Copyright  2000-2005            #
# FRISK Software International (FRISK). All rights reserved.            #
#                                                                       #
# FRISK retains all title and ownership to the Source Code and any      #
# derivative works. FRISK owns copyrights, inventions, know-how and     #
# trade secrets related to the design, operation, amendments or         #
# services of the Source Code and any derivative works which are        #
# developed from the Source Code. FRISK retains all rights to           #
# modify, prepare derivative works of, decompile, reverse engineer,     #
# and disassemble the Source Code from the Software.                    #
#                                                                       #
# Use and modification of the Source Code shall only be permitted by    #
# any licensed party pursuant a prior written authorization from        #
# FRISK.                                                                #
#                                                                       #
#########################################################################

############################  NOTES #####################################
#                                                                       #
# What this script does:                                                #
# *  Sets up symlinks to executables and man pages so they'll work      #
#    without needing full paths each time (All editions), and creates   #
#    the link /etc/f-prot.conf -> $INSTALLDIR/f-prot.conf.default       #
#    if no such link exists.                                            #
# *  Sets up rc-scripts for fpscand, fpmon (FS and MS editions) and     #
#    scan-mail (MS edition) if we find suitable files in rc-scripts.    #
#    It modifies the rc scripts on the fly, changing the 'BASEPATH='    #
#    variable to hold the installation directory. (If you create a      #
#    working rc script for your distro, feel free to share ;)           #
# *  (MS edition only) Offers to configure the system for email         #
#    scanning via Sendmail, Postfix or Qmail. Instructions on how to do #
#    this manually can be found in the documentation that should've     #
#    accompanied this package.  Note that when determining if f-prot    #
#    has already been configured, the program simply searches for the   #
#    regexp /^# F-Prot/ in the relevant config files, so it's very      #
#    important that the comments it creates in those files are not      #
#    removed. Otherwise, it'll append the same config lines again.      #
#                                                                       #
#########################################################################

use strict;
use Cwd;
use Env qw($SHELL);

#Do we have File::Copy?
my $copyfunction;
eval{ use File::Copy; };
if($@){
	$copyfunction = sub {
		open(IN, "<$_[0]") || return 0;
		open(OUT, ">$_[1]") || return 0;
		print OUT <IN>;
		close(IN);
		close(OUT);
		return 1;
	};
}else{
	$copyfunction =\&copy;
}

my $eexist = 17; #usually;
eval{ use POSIX qw(:errno_h); };
if(! $@){ $eexist = EEXIST; }

# This hash holds all variables/info needed to install
my %Config = (
	# The use running this, used as of writing for the user that is to
	# run the crontab entry we generate for fpupdate
	user	=> ($ENV{USER} || (getpwuid($<))[0]),

	#platform info
	OS		=> undef,
	distro	=> undef,
	release	=> undef,
	march	=> undef,
	#f-prot flavor
	edition	=> "Workstation", # untill we find out otherwise
	installdir => undef,
	#linklocations
	bin		=> undef,
	sbin		=> undef,
	man1	=> undef,
	man5	=> undef,
	man8	=> undef,
	marker	=> "# F-Prot - Please leave this line in place" # if this changes, change the regexp that searches for it too.
);

sub main
{
	#gather config and welcome the user
	fillConfigInfo();
	printf("\n\n\t(c) FRISK Software International\n\n\thttp://www.f-prot.com/\n\n");
	printf("\tYou are about to install F-PROT Antivirus for %s %ss\n ", $Config{OS}, $Config{edition});
	printf("\ton a %s%s %s running on %s into the '%s'\n\tdirectory\n\n", $Config{distro}, $Config{OS}, $Config{release}, $Config{march}, $Config{installdir});

	#non-default installdir?
	if( $Config{installdir} ne "/opt/f-prot"){
		print "\tBe warned that the documentation and user manuals assume that\n";
		print "\tF-Prot is installed in the default directory '/opt/f-prot'.\n\n";
		print "\tF-Prot will run just fine from '" . $Config{installdir} . "'\n";
		print "\tbut you will of course have to adjust sample configuration and\n";
		print "\tsuch to match that change.\n\n";
	}

	my $default_configfile = "$Config{installdir}/f-prot.conf.default";
	my $configfile = "$Config{installdir}/f-prot.conf";
	if( ! -e $default_configfile){
		die("\n\nERROR: $default_configfile is missing.\n\n This means that:\n\
a)\tThis script is being used with the wrong version of f-prot,\n\
b)\tThe F-Prot package is damaged or incomplete.\n\
c)\tThis script is not being run from the top-level f-prot directory\n\nRe-run this program when this issue is resolved.\n\n");
	}

	#
	# Copy f-prot.conf.default to f-prot.conf and symlink
	# /etc/f-prot.conf to that file, that way the user can unpack a
	# fresh tarball over the installation directory without
	# overwriting his config file
	#

	unless (-e $configfile) {
		unless ( $copyfunction->( $default_configfile => $configfile ) ) {
			die("\nFailed to copy $default_configfile to $configfile\n".
				"\nPlease investigate and fix the above error and then re-run this script\n");
		}
	} else {
		print "$configfile already exists, not copying $default_configfile to that location\n";
	}

	makeLink("/etc/f-prot.conf", $configfile);

	makeSymlinks();

	print "\nChanging file access permissions on the installed files and directories ...";
	changePermissions();
	print "ok";

	#
	# Figure out what to do wrt the license key, do we already have a
	# set up key? do we need to make a trial key?
	#

	print "\nChecking if you have an existing license key...";

	if (-e "$Config{installdir}/license.key") {
		print "yes\n";
		print "\nFound an existing license key in $Config{installdir}/license.key, updating antivir.def ...\n\n";

		updateWithExistingKey();
	} else {
		print "no\n";

        print "\nWe can't find an existing license key from a previous install\n\
\t(1) Enter an existing license key you have (e.g. from an e-mail)\n\
\t(2) Apply for a 30 day trial key\n";

      existingkeyortrial:
		if ((my $reply = Question("Existing key (1) or trial (2)", "1")) =~ /^([12])$/ ) {
            if ($reply == 1) {
                # Existing key
                askForExistingKey();
                writeExistingKey();
                updateWithExistingKey();
            } elsif ($reply == 2) {
                # Trial
                $Config{is_trial} = 1;
                askTrialQuestions();
                writeTrialData();
                if (getTrialKey()) {
                    # The trial key exists now!
                    writeExistingKey();
                    updateWithExistingKey();
                } else {
                    couldNotGetTrialKeyMessage();
                }
            } else {
                # Never happens, really!
                die "Internal error";
            }
        } else {
            print "Invalid reply '$reply', try again\n";
            goto existingkeyortrial;
        }
    }

	setupFpupdateCrontab();

	setupServices();

	print "\n\n\tAll done!\n\n";

	# print only if MTA edition
	if ( -e mailtools ){
		print "\n\nIf you reconfigured your MTA you should restart it now to activate the changes.\n\n";
	}

	print "\tHave a nice day\n\nFrisk software (www.f-prot.com)\n\n";
}

sub fillConfigInfo
{
	# OS, cpu arch and OS release.
	chomp(($Config{OS} = `uname -s`));
	chomp(($Config{march} = `uname -m`));
	chomp(($Config{release} = `uname -r`));
	$Config{release} =~ s/(.+?)-.*/$1/; # grab release/kernel/whatever up to the first '-' character.

	# distro
	if ($Config{OS} =~ /linux/i)
	{
		if (-e "/etc/mandriva-release"){
			$Config{distro} = 'Mandriva ';
		}
		elsif (-e "/etc/redhat-release"){
			$Config{distro} = 'RedHat '; # The space is there for formatting reasons...
		}
		elsif (-e "/etc/SuSE-release"){
			$Config{distro} = 'SuSE ';
		}
		elsif (-e "/etc/debian_version"){
			$Config{distro} = 'Debian ';
		}
		elsif (-e "/etc/slackware-version"){
			$Config{distro} = 'Slackware ';
		}
		else{
			$Config{distro} = 'Unknown ';
		}
	}
	# Where am I?
	if($0 =~ /^\./ or -f $0) {
        # Catch `./install-f-prot.pl' and `perl install-f-prot.pl'
		$Config{installdir} = getcwd();
	}else{
		$Config{installdir} = $0;
		$Config{installdir} =~ s/(.+)\/.+/$1/; # throw away the last slash and everything after it
	}
	#which f-prot flavor
	if(-e $Config{installdir} . "/fstools"){
		$Config{edition} = "FileServer";
	}
	if(-e $Config{installdir} . "/mailtools" ){
		$Config{edition} = "MailServer";
	}
	#link locations (we check for failure later when it's clear which ones we need)
	$Config{bin} = findDir("/usr/local/bin", "/usr/bin", "/bin");
	$Config{sbin} = findDir("/usr/local/sbin", "/usr/sbin", "/sbin");
	
	my @MANPATHS = split( ':', $ENV{MANPATH});
	$Config{man1} = findDir( @MANPATHS, "/usr/local/man", "/usr/share/man" ) . "/man1";
	$Config{man5} = findDir( @MANPATHS, "/usr/local/man", "/usr/share/man" ) . "/man5";
	$Config{man8} = findDir( @MANPATHS, "/usr/local/man", "/usr/share/man" ) . "/man8";
}

sub makeSymlinks
{
	# Everyone needs workstation files
	# F-Prot
	my $question = "Would you like to have a wrapper script created for fpscan.\nIf you choose 'no' a symbolic link will be created instead, you should consider this if the wrapper script does not work for you, for example due to your system using a non sh or csh compatible shell.";
	if ((my $reply = Question($question, "Y/n")) =~ /^y/i )
	{
		$Config{bin} = makeScriptPathOK($Config{bin}, "F-PROT Antivirus command line scanner (fpscan)");
		makeScript($Config{bin}."/fpscan",createFpscanScript($Config{installdir}."/fpscan"));
	}
	else
	{
		$Config{bin} = makeLinkPathOK($Config{bin}, "F-PROT Antivirus command line scanner (fpscan)");
		makeLink($Config{bin} . "/fpscan", $Config{installdir} . "/fpscan");
	}
	# man fpupdate
	$Config{man8} = makeLinkPathOK($Config{man8}, "section 8 manuals");
	makeLink($Config{man8} . "/fpupdate.8", $Config{installdir} . "/doc/man/fpupdate.8");
	# man f-prot
	$Config{man1} = makeLinkPathOK($Config{man1}, "section 1 manuals");
	makeLink($Config{man1} . "/fpscan.1", $Config{installdir} . "/doc/man/fpscan.1");
	# man f-prot.conf
	$Config{man5} = makeLinkPathOK($Config{man5}, "section 5 manuals");
	makeLink($Config{man5} . "/f-prot.conf.5", $Config{installdir} . "/doc/man/f-prot.conf.5");
	if( $Config{edition} eq "Workstation" ){ # We're done
		return;
	}
	# add links to fpscand for file server editions
	$Config{sbin} = makeLinkPathOK($Config{sbin}, "F-Prot daemon scanner (fpscand)");
	makeLink($Config{sbin} . "/fpscand", $Config{installdir} . "/fpscand");

    # fpmon is currently only shipped on Linux (in 6.0.1, 6.0.2, 6.0.3, 6.1.x and 6.2.x)
    unless ($Config{OS} eq 'Linux') {
        makeLink($Config{sbin} . "/fpmon", $Config{installdir} . "/fstools/fpmon");
        makeLink($Config{man8} . "/fpmon.8", $Config{installdir} . "/doc/man/fpmon.8");
    }

	makeLink($Config{man8} . "/fpscand.8", $Config{installdir} . "/doc/man/fpscand.8");
	makeLink($Config{man8} . "/fp.so.8", $Config{installdir} . "/doc/man/fp.so.8");

	if($Config{edition} eq "FileServer"){
		return;
	}
	makeLink($Config{man8} . "/scan-mail.pl.8", $Config{installdir} . "/doc/man/scan-mail.pl.8");
	if ($Config{OS} =~ /aix/i){
		return;
	}
	makeLink($Config{man8} . "/fp-milter.8", $Config{installdir} . "/doc/man/fp-milter.8");
	makeLink($Config{man8} . "/fp-qmail.8", $Config{installdir} . "/doc/man/fp-qmail.8");
}

sub changePermissions
{
	chmod(0755, $Config{installdir} . "/fpscan") || warn "failed\n$Config{installdir}/fpscan may have wrong file permissions\n";
	chmod(0700, $Config{installdir} . "/fpupdate") || warn "failed\n$Config{installdir}/fpupdate\n";

	# Everything below applies only to file servers and mail servers
	return if $Config{edition} eq "Workstation";

	chmod(0755, $Config{installdir} . "/fpscand") || warn "failed\n$Config{installdir}/fpscand may have wrong file permissions\n";
	chmod(0700, $Config{installdir} . "/fstools/fpmon") || warn "failed\n$Config{installdir}/fstools/fpmon may have wrong file permissions\n";

	# Everything below applies only to mail servers
	return if $Config{edition} eq "FileServer";

	chmod(0777, $Config{installdir} . "/backup") || warn "failed\n$Config{installdir}/backup may not be writeable by your mta user\n";

	chmod(0755, $Config{installdir} . "/mailtools/scan-mail.pl") || warn "failed\n$Config{installdir}/mailtools/scan-mail.pl may have wrong file permissions\n";

	# we dont ship qmail and milter stuff with aix versions
	if( $Config{OS} =~ /aix/i ){
		return;
	}

	chmod(0755, $Config{installdir} . "/mailtools/fp-milter") || warn "failed\n$Config{installdir}/mailtools/fp-milter may have wrong file permissions\n";
	chmod(0755, $Config{installdir} . "/mailtools/fp-qmail") || warn "failed\n$Config{installdir}/mailtools/fp-qmail may have wrong file permissions\n";

}

sub setupFpupdateCrontab
{
	if (FpupdateInCrontab()) {
		print <<EOF;

Detected an existing fpupdate entry in /etc/crontab, a new one will not be generated

EOF
		return;
	}

	# Private subs to make global/user crontab entries
	my $global_crontab_entry = sub {
		my ($min, $user, $fpupdate) = @_;
		sprintf "%d * * * * %s %s > /dev/null", $min, $user, $fpupdate;
	};

	my $user_crontab_entry = sub {
		my ($min, $fpupdate) = @_;
		sprintf "%d * * * * %s > /dev/null", $min, $fpupdate;
	};

	# Gets a random minute between 0 and 59 inclusive
	my $min = int rand 60;
	# path to fpupdate
	my $fpupdate = $Config{installdir} . "/fpupdate";

	my $user_entry	 = $user_crontab_entry->($min, $fpupdate);
	my $global_entry = $global_crontab_entry->($min, $Config{user}, $fpupdate);

	print <<EOF;

We've generated the following crontab entries to update the
antivir.def file via fpupdate. Updates will be run hourly at a
randomly picked minute to distribute load, and thus make your updates
faster than if they were run during obvious high load times, e.g. on
the hour.

The global crontab entry we made to add to /etc/crontab is the following:

	$global_entry
EOF


	if ((my $reply = Question("Would you like to have this crontab appended to /etc/crontab", "Y/n")) =~ /^y/i ) {
		# Two argument open for 5.6 compatability
		open my $crontab, ">>/etc/crontab" or die $!;

		my $str = <<EOF;

# This entry was added by the `install-f-prot.pl' script in the F-PROT
# package to update the antivir.def file in
# $Config{installdir}/antivir.def

$global_entry

EOF

		print $crontab $str;
	} else {
		print <<EOF;

No changes to /etc/crontab have been made but you should manually add
the crontab entry above or its equivalent somewhere so that the
antivir.def file is kept up to date.

EOF

	}
}

sub FpupdateInCrontab
{
	open my $fh, "</etc/crontab";

	while (my $line = <$fh>) {
		return 1 if $line =~ /fpupdate/;
	}
	return;
}

sub setupServices
{
	my $reply;
	if( $Config{edition} eq "Workstation"){
		return;
	}
	print "\nTrying to load the dazuko kernel module with /sbin/modprobe...",;
	if( 0 == system("/sbin/modprobe dazuko")){
		print "success.\n";
		if( ($reply = Question("Would you like to configure On-Access file scanning now", "Y/n")) =~ /^y/i ){
			setupFPMon();
		}else{
			print "\n skipping fpmon configuration\n";
		}
	}else{
		print "\n\n";
		print "This program cannot automatically configure on-access file scanning.\n";
		print "If you wish to do on-access scanning, please read the man pages for\n";
		print "fp.so and/or fpmon (man fp.so  / man fpmon).	 Further information\n";
		print "and detailed instructions can be found there and in the help files\n";
		print "and at www.f-prot.com/support/unix/index.html & forum.f-prot.com .\n\n";
	}
	
	return if $Config{edition} eq "Workstation";

    print "\nfpscand should be running... attempting to start fpscand";

    if( 0 != system("pkill fpscand ; $Config{installdir}/fpscand")){
        print("\nfpscand failed to start.\n");
        if ((my $reply = Question("Continue with installation", "Y/n")) =~ /^y/i ) {
            print "\nInstallation will now continue, you can try running fpscand later\n";
        } else {
			print "\nExiting installation program\n";
            exit 1;
        }
    }

    if( defined (my $file = checkForRCFile("fpscand"))){
        if(($reply = Question("Should fpscand be started at system boot time", "Y/n")) =~ /^y/i ){
            doRCFile($file);
        }
    }

	return if $Config{edition} eq "FileServer";

	print "\n\n####################################################################################\n\n";
	print "\tIf you use Sendmail, Postfix or QMail as your MTA, this program can\n";
	print "\tconfigure them to scan incoming emails using fpscand and scan-mail.pl.";
	print "\n\n####################################################################################\n\n";

	if( (my $reply = Question("Do you want the installation program to add virus scanning to your MTA setup", "Y/n")) !~ /^y/i){
		print "\nvery well. Not configuring mailservers at this point.\n\n\tThe 'SCANMAIL_STARTUP' variable in /etc/f-prot.conf may need manual adjustments.\n";
		return;
	} else {
		doScanmailConfig();
	}
}

sub setupFPMon
{
	my @incpaths;
	my @excpaths;
	print "\n\nEnter include paths for fpmon to do on-access scanning for, one at a time.\n";
	print "Subdirectories are automatically included.\n";
	while( my $path = Question("Enter a path (leave blank when done)", "")){
		push(@incpaths, $path);
	}
	my $paths = join(':', @incpaths);
	if( $paths eq ""){
		print "\n\nWARNING:\nNo input paths specified. Not starting fpmon.\n";
		print "You can re-run this program to set up fpmon later or modify /etc/f-prot.conf manually.\n";
		return;
	}
	setConfigOption("FPMON_INCLUDEPATHS", $paths);
	print "\n\nEnter paths which fpmon should specifically exclude from on-access scanning, one at a time.\n";
	print "Usually, these will be subdirectories of the included paths.\n";
	while( my $path = Question("Enter a path (leave blank when done)", "")){
		push(@excpaths, $path);
	}
	my $paths = join(':', @excpaths);
	setConfigOption("FPMON_EXCLUDEPATHS", $paths);
	if((my $reply = Question("Would you like to start fpmon now", "Y/n")) =~ /^y/i ){
		if( 0 != system("$Config{installdir}/fstools/fpmon")){
			die("\nfpmon failed to start. Please investigate and re-run this program.\n");
		}
		if( defined (my $file = checkForRCFile("fpmon"))){
			if(($reply = Question("Would you like to start fpmon at system boot", "Y/n")) =~ /^y/i ){
				doRCFile($file);
			}
		}
	}
}

sub doScanmailConfig
{
	print "\nScan-mail.pl needs to know which mailserver you use.\n";
	print "\n 1 - Qmail\t Configure scan-mail.pl for use with fp-qmail";
	print "\n 2 - Postfix\t Configure scan-mail.pl for use with Postfix";
	print "\n 3 - Sendmail\t Configure scan-mail.pl for use with Sendmail/milter";
	print "\n";
	my $args = "";
	my $reply;
	while( ($reply = Question("Which mail server do you want scan-mail.pl to service", "")) !~ /^(1|2|3)$/){
		print "\n Invalid reply '$reply'. Try again\n";
	}
	if( $reply	  == 1){
		$args = doQmailStuff();
	}elsif($reply == 2){
		$args = doPostfixStuff();
	}elsif($reply == 3){
		$args = doSendmailStuff();
	}
	if($args eq ""){
		return undef;  # user decided not to configure mta, so we don't touch the config file
	}
	setConfigOption("SCANMAIL_STARTUP", $args);
	if( ($reply = Question("Would you like to start scan-mail.pl now", "Y/n")) =~ /^y/i){
		if( 0 != system("$Config{installdir}/mailtools/scan-mail.pl $args")){
			print "\n\nscan-mail.pl failed to start. Please investigate...\n\n";
			return undef;
		}
		if( defined (my $file = checkForRCFile("scan-mail"))){
			if(($reply = Question("Would you like to start scan-mail.pl at system boot", "Y/n")) =~ /^y/i ){
				doRCFile($file);
			}
		}
	}
	return 1;
}

sub doQmailStuff
{
	my $ret = "--daemon";
	print "\n\n\tTo use f-prot with qmail, fp-qmail must take the place of the qmail-queue program";
	print "\n\tand qmail-queue must be renamed to qmail-queue.orig and both must have correct";
	print "\n\townership and permissions.\n";
	my $reply = Question("Do you wish to make these changes now", "Y/n");
	if( $reply !~ /^y/i ){
		print "\nVery well. Instructions on how to do this manually can be found in the accompanying documentation.\n";
		return $ret;
	}
	# following code is critical. It must make sure the system is always in a usable state.
	# I.e. it should be considered atomic from the users point of view
	my $qqueue = getPathToExistingFile("qmail-queue", 1, "/var/qmail/bin/qmail-queue");
	my ($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$atime,$mtime,$ctime,$blksize,$blocks) = stat($qqueue);
	my $tempfile = $qqueue . ".f-prot";
	print "\npreparing fp-qmail";
	if( ! &$copyfunction("$Config{installdir}/mailtools/fp-qmail", $tempfile) ){
		die("\nFailed to copy fp-qmail to $tempfile\n". \
			"\nNo changes have been made to your mailserver setup yet." . \
			"\nPlease investigate and fix the above error and then re-run this script\n");
	}
	if( ! chown($uid, $gid, $tempfile) ){
		unlink($tempfile);
		die("\n chown() on $tempfile failed: $!\n" . \
			"\nNo changes have been made to your mailserver setup yet." . \
			"\nPlease investigate and fix the above error and then re-run this script\n");
	}
	if( ! chmod($mode, $tempfile) ){
		unlink($tempfile);
		die("\n chmod() on $tempfile failed: $!\n". \
			"\nNo changes have been made to your mailserver setup yet." . \
			"\nPlease investigate and fix the above error and then re-run this script\n");
	}
	print "\nswitching binaries...";
	if( -e $qqueue . ".orig" ){
		#Propably an upgrade or a re-run of this script. Either way, remove qmail-queue, but dont overwrite
		#qmail-queue.orig
		print "\n ...what's this?\n\n ...qmail-queue.orig already exists. I'll leave it alone...";
		if( ! unlink($qqueue) ){
			unlink($tempfile);
			die("\n unlink() on previous $qqueue failed: $!\n" . \
				"\nNo changes have been made to your mailserver setup yet." . \
				"\nPlease investigate and fix the above error and then re-run this script\n");
		}
	} else {
		if( ! rename($qqueue, $qqueue . ".orig") ){
			unlink($tempfile);
			die("\nCannot rename $qqueue to $qqueue.orig: $!\n " . \
				"\nNo changes have been made to your mailserver setup yet." . \
				"\nPlease investigate and fix the above error and then re-run this script\n");
		}
	}
	if( ! rename($tempfile, $qqueue) ){
		print "Cannot rename $qqueue to $qqueue.orig: $!\n ";
		# Try to back out.
		if( ! rename($qqueue . ".orig", $qqueue) ){
			print "\n\tERROR: Failed to roll back changes. Your mailserver setup may not be able to deliver mail";
			print "\nuntill qmail-queue.orig is renamed back to qmail-queue with";
			printf("\nuid %d, gid %d and permission bits set to %o\n", $uid, $gid, $mode);
		}else{
			print "\nNo changes have been made to your mailserver setup yet.";
			print "\nPlease investigate and fix the above error and then re-run this script\n";
		}
		unlink($tempfile);
		die("\nExiting\n");
	}
	print " done\n";

	return $ret;
}

sub doPostfixStuff
{
	print "\n\n\tTo enable email-scanning with Postfix mailservers, Postfix's configuration";
	print "\n\tfiles need to be modified.\n";
	print "\n\tIf you are upgrading from a previous version and already have a working";
	print "\n\tconfiguration in place, you should skip this step.\n";
	print "\n\tIf you are trying to repair a broken configuration, then remove all f-prot";
	print "\n\trelated config lines from both master.cf and main.cf before proceeding.\n\n";

	my $reply = Question("Do you wish to make the changes now", "Y/n");
	if($reply !~ /^y/i ){
		print "\nOperation cancelled. Refer to scan-mail.pl's man page for instructions on how to\n";
		print "do this manually. Furthermore, you must remember to update the 'SCANMAIL_STARTUP' variable\n";
		print "in /etc/f-prot.conf at the same time if you plan to use a rc-script to start scan-mail.pl\n\n";
		return "";
	}
	my $ret = "";
	# find config files
	my $maincf = getPathToExistingFile("main.cf", 1, "/etc/postfix/main.cf");
	my $mastercf = $maincf;
	$mastercf =~ s/main.cf/master.cf/;
	$mastercf = getPathToExistingFile("master.cf", 1 , $mastercf);
	backupFile($maincf);
	backupFile($mastercf);
	my $mainline = "\n$Config{marker}\ncontent_filter = smtp:[127.0.0.1]:10025\n";
	my $masterlines = "\n$Config{marker}\nscan unix - - n - 10 smtp\n";
	$masterlines .= "localhost:10026 inet n - n - 10 smtpd\n";
	$masterlines .= "\t-o content_filter= \n";
	$masterlines .= "\t-o local_recipient_maps= \n";
	$masterlines .= "\t-o relay_recipient_maps= \n";
	$masterlines .= "\t-o myhostname=localhost \n";
	$masterlines .= "\t-o smtpd_helo_restrictions= \n";
	$masterlines .= "\t-o smtpd_client_restrictions= \n";
	$masterlines .= "\t-o smtpd_sender_restrictions= \n";
	$masterlines .= "\t-o smtpd_recipient_restrictions=permit_mynetworks,reject \n";
	$masterlines .= "\t-o smtpd_use_tls=no \n";
	$masterlines .= "\t-o mynetworks=127.0.0.0/8 \n";

	print "\n\n\tScan-mail.pl can act as a mail filter with postfix in 2 ways;";
	print "\neither as a spawn service, where scan-mail.pl is started for each request";
	print "\nor as a stand-alone smtp proxy running in the background.\n";
	print "\n\t See 'man scan-mail.pl' for details\n";
	print "\n\tChoose one:\n";
	print "\n 1) \tSpawn service";
	print "\n 2) \tStandalone SMTP proxy\n";
	while(($reply = Question("Which mode would you like scan-mail.pl to operate in", "")) !~ /^(1|2)$/){
		print "\nInvalid reply '$reply'.\n\tChoose either '1' or '2':\n";
	}
	if($reply == '1'){
		print "\nSpawn service it is\n";
		$masterlines .= "localhost:10025 inet n n n - 10 spawn user=nobody argv=$Config{'installdir'}/mailtools/scan-mail.pl -postfix 127.0.0.1:10026";
		$ret = "";
	}else{
		print "\nStandalone smtp proxy it'll be then\n";
		$ret = "--daemon --proxy --proxy_address 127.0.0.1:10025 --smtp_address 127.0.0.1:10026";
	}

	# Let's make the changes
	print "\nUpdating $maincf ...";
	# first we check if we've already made the necessary changes in a previous run perhaps
	open(MAIN, "<$maincf") || die("Cannot open $maincf for reading: $!\nPlease investigate and then rerun this script\n");
	my @m = <MAIN>;
	close(MAIN);
	if( scalar grep(/$Config{'marker'}/, @m)){
		print "\n\n\tPrevious F-Prot configuration section found in $maincf";
		print "\n\tLeaving configuration intact\n";
	}else{
		open(MAIN, ">>$maincf") || die("Cannot open $maincf for updates: $!\nPlease investigate and then rerun this script\n");
		print MAIN $mainline;
		close(MAIN);
		print " done\n";
	}
	print "\nUpdating $mastercf ...";
	# again, we first check if we've already made the necessary changes
	open(MASTER, "<$mastercf") || die("Cannot open $mastercf for reading: $!\nPlease investigate and then rerun this script\n");
	my @m = <MASTER>;
	close(MASTER);
	if( scalar grep(/$Config{'marker'}/, @m)){
		print "\n\n\tPrevious F-Prot configuration section found in $mastercf";
		print "\n\tLeaving configuration intact\n";
	}else{
		open(MASTER, ">>$mastercf") || die("Cannot open $mastercf for updates: $!\nPlease investigate and then rerun this script\n");
		print MASTER $masterlines;
		close(MASTER);
		print " done\n";
		if ( $Config{distro} eq "Mandriva " ){
			print "\n\n\t\tWARNING\n\n";
			print "\tSome versions of Mandriva Linux ship with Postfix already setup to have\n";
			print "a non-filtering postfix instance listening on port 10026.\n";
			print "If postfix fails to start after this installation completes, you'll\n";
			print "have to edit $mastercf yourself and remove or comment out either one\n";
			print "of the sections which defines a postfix instance on port 10026.";
		}

	}
	return $ret;
}

sub doSendmailStuff
{
	print "\nChecking if sendmail has milter support compiled in ...";
	if( 0 == system("sendmail -d0.13 -bv root | grep MILTER > /dev/null"))
	{
		print " yes\n";
	}else{
		print " no\n";
		print "\n\n\tFor F-Prot to work with Sendmail, Sendmail must have been";
		print "\n\tcompiled with milter support. Please install or compile sendmail";
		print "\n\twith milter support and then run this script again to enable fp-milter.\n\n";
		die("\nExiting\n");
	}
	my $cflines = "\n$Config{marker}\nO InputMailFilters=fp-milter\n";
	$cflines .= "Xfp-milter, S=inet:12200\@127.0.0.1, F=T,T=E:8m;C:5m;R:4m;S:2m\n";
	my $mclines = "\n$Config{marker}\ndefine(`_FFR_MILTER', `True')\n";
	$mclines .= "INPUT_MAIL_FILTER(`fp-milter', `S=inet:12200\@127.0.0.1, F=T, T=E:8m;C:5m;R:4m;S:2m')\n";
	# Find config file
	print "\nPlease enter the path to your sendmail configuration file, either the .mc file or the .cf file\n";
	my $default = "";
	if( -e "/etc/mail/sendmail.mc" ){
		$default = "/etc/mail/sendmail.mc";
	}elsif( -e "/etc/mail/sendmail.cf" ){
		$default = "/etc/mail/sendmail.cf";
	}
	my $sendmailc = getPathToExistingFile("sendmail.(mc|cf)", 1, $default);
	#Make a backup copy
	backupFile($sendmailc);
	my $ret = "--daemon --milter ";
	if( $sendmailc =~ /\.mc$/ ){
		# better just use the address then, since there is no guarantee that the cf file will be in the same place
		$ret .= "inet:12200\@127.0.0.1";
	}elsif( $sendmailc =~ /\.cf$/ ){
		$ret .= $sendmailc;
	}else{
		die("not a .mc and not .cf?!? Something is horribly wrong");
	}
	#Search for f-prot inside file
	print "\nModifying $sendmailc ...";
	open(CF, "<$sendmailc" ) || die("Cannot open $sendmailc for reading: $!\nPlease investigate and then rerun this script\n");
	if( scalar grep(/$Config{marker}/, <CF>)){
		print "\n\n\tPrevious F-Prot configuration section found in $sendmailc";
		print "\n\tLeaving configuration intact\n";
		close(CF);
	}else{
		close(CF);
		open(CF, ">>$sendmailc") || die("Cannot open $sendmailc for updates: $!\nPlease investigate and then rerun this script\n");
		if( $sendmailc =~ /\.mc$/ ){
			print CF $mclines;
		}else{
			print CF $cflines;
		}
		close(CF);
		print " done\n";
	}
	if( $sendmailc =~ /\.mc$/ ){
		print "\n\n\t You must now generate your sendmail.cf file and reload sendmail for the changes to take effect.\n";
	}
	return $ret;
}

sub checkForRCFile
{
	my $prog = shift;
	my $ending;
	if( $Config{OS} =~ /linux/i ){
		$ending = $Config{distro};
		$ending =~ tr/A-Z/a-z/;
		$ending =~ s/\s*$//;
	} else {
		$ending = $Config{OS};
	}
	my $prog = "$Config{installdir}/rc-scripts/$prog.rc-$ending";
	return $prog if -e $prog;
	return undef;
}

sub doRCFile
{
	my $filename = shift;
	my $service = $filename;
	my $target;
	$service =~ s/^.+\/(.+)\.rc-.+$/$1/;
	my $command = undef;
	open(SRC, $filename) || die("Cannot open $filename: $!\n Please investigate and then re-run this program\n\n");
	if( -e "/etc/init.d"){
		$target = "/etc/init.d/$service";
	}elsif( -e "/etc/rc.d"){
		$target = "/etc/rc.d/$service";
	}else{
		print "\n Not sure where this OS/distro keeps it's rc-scripts.";
		print "\n You'll have to install $filename in the correct location manually.\n";
		return;
	}
	open(RC, ">$target") || die("Cannot open $target: $!\n Please investigate and then re-run this program\n\n");
	while(<SRC>){
		my $l = $_;
		if($l =~ /^BASEPATH/){
			$l =~ s/^BASEPATH=.+$/BASEPATH=$Config{installdir}/;
		}
		print RC $l;
	}
	close(SRC);
	close(RC);
	chmod(0755, "$target") || warn("Unable to change file permissions of $target: $!\n Continuing anyway\n");

	if($Config{OS} =~ /linux/i && ( $Config{distro} =~ /suse|redhat|mandriva|debian/i )){
		if(		$Config{distro} =~ /redhat/i){
			$command = "chkconfig --add $service";
		}elsif( $Config{distro} =~ /suse/i){
			$command = "chkconfig $service on";
		}elsif( $Config{distro} =~ /mandriva/i){
			$command = "chkconfig --add $service start";
		}elsif( $Config{distro} =~ /debian/i){
			$command = "update-rc.d $service start 12 2 3 4 5 . stop 21 0 1 6 .";
		}
		if( 0 != system($command) ){
			print "\n\n$command failed! $service will NOT be started automatically on the next reboot.";
			print "\nInstallation continues, but you should investigate this matter.\n";
		}
	}else{
		print "\nDon't know how this OS/distro handles boot scripts.";
		print "\nYou must manually ensure that $target is executed at system boot time.";
	}
}

sub backupFile
{
	my $srcfile = shift;
	print "\n\nMaking backup of $srcfile...";
	if( -e $srcfile . ".fprotbackup"){
		print " hang on\n\n\tBackup file exists... Not making new backup.\n";
	}else{
		if( ! &$copyfunction($srcfile, $srcfile . ".fprotbackup") ){
			die("Backup failed: $!\n\tPlease investigate and then re-run this script\n");
		}
		print " done\n";
	}
}

sub getPathToExistingFile
{
	my ($promptfor, $fullpath, $default) = @_;
	my $cre = qr/$promptfor$/;
	my $question = "Where is your $promptfor";
	if($fullpath){
		$question .= " (full path please) ";
	}
	my $reply;
	while( 1 ){
		$reply = Question($question, $default);
		if( $fullpath && ! ($reply =~ /^\// && $reply =~ $cre) ){
			print "\nPlease specify a full path to $promptfor";
			next;
		}
		if( ! -e $reply ){
			print "\n$reply doesn't exist";
			next;
		}
		if( ! -f $reply){
			print "\n$reply is not a regular file";
			next;
		}
		last;
	}
	return $reply;
}

sub makeLink
{
	my ($linkname, $target) = @_;
	if( ! symlink($target, $linkname) ){
		# it's ok to fail if link exists and points to the correct file.
		if( int($!) == $eexist){ #File exists
			my $point = readlink($linkname);
			return if $point eq $target;
			# if it points elsewhere we should ask the user.
			print "\nLink $linkname already exists, pointing to $point.\n";
			if( (my $reply=Question("Replace it with a link pointing to $target", "Y/n")) =~ /^y/i ){
				if( ! unlink($linkname) ){
					die("\nCannot remove $linkname: $!\n Please investigate and then re-run this script\n\n");
				}
				return makeLink($linkname, $target);
			}
			die("\n The installation cannot continue unless /etc/f-prot.conf is set up.\n\nFix the above errors and then re-run this script or install manually\n\n");
		}
		die("\n\n Failed to create symbolic link '$linkname -> $target': $! \n\n Fix the above errors and then re-run this script or install manually\n\n");
	}
}

sub askTrialQuestions
{
    print "We'll need to get your name and e-mail to send to the trial server for bookkeeping\n";

  name:
    if ((my $reply = Question("Your name")) !~ /^\s*$/ ) {
        chomp $reply;
        $Config{trial}->{name} = $reply;
    } else {
        print "\nNo name supplied, try again";
        goto name;
    }

    # It would be pointless to do any further checking on the e-mail
    # here, people can supply a bogus e-mail anyway, no point in
    # requiring a bogus e-mail in strict RFC 822 format!
  email:
    if ((my $reply = Question("Your email")) =~ /.\@./ ) {
        chomp $reply;
        $Config{trial}->{email} = $reply;
    } else {
        print "\nDoesn't look like an e-mail address, try again";
        goto email;
    }

  where:
    # TODO: make this configurable?
    $Config{trial}->{where} = "n/a";
}

sub writeTrialData
{
	my $default_product_data = "$Config{installdir}/product.data.default";
	my $product_data = "$Config{installdir}/product.data";
	if( ! -e $default_product_data){
		die("\n\nERROR: $default_product_data is missing.\n\n This means that:\n\
a)\tThis script is being used with the wrong version of f-prot,\n\
b)\tThe F-Prot package is damaged or incomplete.\n\
c)\tThis script is not being run from the top-level f-prot directory\n\nRe-run this program when this issue is resolved.\n\n");
	}

	# Copy product.data.default just like the .default f-prot.conf
	unless (-e $product_data) {
		unless ( $copyfunction->( $default_product_data => $product_data ) ) {
			die("\nFailed to copy $default_product_data to $product_data\n".
				"\nPlease investigate and fix the above error and then re-run this script\n");
		}
	}

    open my $fh, ">>$product_data" or die $!;

    # Write out name, email, where to product.data
    for my $k (qw(name email where)) {
        my $v = $Config{trial}->{$k};
        printf $fh "%s=%s\n", $k, $v;
    }
    close $fh;
}


sub askForExistingKey
{
    my $klen = 34;# 39 with dashes included

  askforkey:
    if ((my $reply = Question("Please enter your existing key")) =~ /(\S)/ ) {
        $reply =~ tr/-//d;

        # XXX: I had a 32 char key although they're supposed to be 34 chars?
        unless (length $reply >= 30) { # XXX: hack!
            print "Key looks invalid (not 34 characters long, try again\n";
            goto askforkey;
        } else {
            $Config{license_key} = $reply;
        }
    } else {
        print "No data entered, try again\n";
        goto askforkey;
    }
}

sub writeExistingKey
{
    my $file = $Config{installdir} . "/license.key";

    die "Internal error, $file already exists" if -e $file;

    open my $lk, ">$file" or die $!;

    my $msg;
    my $time = scalar localtime;
    if ($Config{is_trial}) {
        $msg  = "# This is a trial key made for $Config{trial}->{name} <$Config{trial}->{email}>\n";
        $msg .= "# on $time by install-f-prot.pl\n";
    } else {
        $msg = "# This is a valid license key written by install-f-prot.pl on $time\n";
    }
    print $lk <<LICK;
$msg
FPROT_LICENSE_KEY="$Config{license_key}"
LICK

    close $lk;
}

sub makeLinkPathOK
{
	my ($path, $component) = @_;
	my $reply;
	while( 1 ){
		$reply = Question("Where do you want a symbolic link to '$component' to be created", $path);
		return $reply if -e $reply;
		if( $reply !~ /^(\.{1,2})?\// ){
			print "\n\t$reply doesn't look like a sane path. Please enter a usable path for the symlink\n\n";
		}else{
			my $create = Question("$reply doesn't exist. Create it", "Y/n");
			if ( $create =~ /^y/i ){
				last if( mkdir($reply, 0755) );
				print "\nCannot create $reply: $!\n";
			}
		}
	}
	return $reply
}

sub makeScriptPathOK
{
	my ($path, $component) = @_;
	my $reply;
	while( 1 ){
		$reply = Question("Where do you want a wrapper script for '$component' to be created", $path);
		return $reply if -e $reply;
		if( $reply !~ /^(\.{1,2})?\// ){
			print "\n\t$reply doesn't look like a sane path. Please enter a usable path for the script\n\n";
		}else{
			my $create = Question("$reply doesn't exist. Create it", "Y/n");
			if ( $create =~ /^y/i ){
				last if( mkdir($reply, 0755) );
				print "\nCannot create $reply: $!\n";
			}
		}
	}
	return $reply
}

                                                                                                                                                                                                                                                                                        
sub updateWithExistingKey
{
	if( 0 != system($Config{installdir} . "/fpupdate")){
        print "\n\nUnable to update `antvir.def' with the provided license key.\n" .
              "The error message above should explain why.\n";

        if ((my $reply = Question("Continue with installation", "Y/n")) =~ /^y/i ) {
            print "\nInstallation will now continue, you can try running fpupdate later to update `antivir.def'\n";
        } else {
			print "\nExiting installation program\n";
            exit 1;
        }
    }
}

sub getTrialKey
{
    my $key;
    my $fpupdate = $Config{installdir} . "/fpupdate";

    chomp(my @out = qx[$fpupdate --trial]);
    for (@out) {
        $key = $1 if /FPROT_LICENSE_KEY="(.+)"/;
        $key =~ s/-//g;
    }

    if ($key) {
        $Config{license_key} = $key;
        return 1;
    } else {
        print "Couldn't get a license key from fpupdate output, output was:\n\n";

        print $_, "\n" for @out;

        if ((my $reply = Question("Continue with installation", "Y/n")) =~ /^y/i ) {
            return;
        } else {
            die "Unable to aquire trial key";
        }
    }
}

sub couldNotGetTrialKeyMessage
{
    print "\nUnable to acquire trial key, so we haven't updated antivir.def\n";
    print "\n";
    print "You will need to acquire a trial key through other means, such as running `fpupdate --trial' manually,\n";
    print "Then the following will have to be added to `$Config{installdir}/license.key':\n\n";
    print "FPROT_LICENSE_KEY=TRIAL_KEY\n\n";
    print "Where `TRIAL_KEY' is your trial key\n\n";

    # This is just here to make the user stop and read this message
    if ((my $reply = Question("Continue with installation", "Y/n")) =~ /^y/i ) {
        return;
    } else {
        die "Unable to aquire trial key";
    }
}

sub updateWithTrialKey
{
	if( 0 != system($Config{installdir} . "/fpupdate")){
        die("\n\tUpdate check failed. That indicates  something is seriously wrong.\n\nExiting\n");
    }
}

sub setConfigOption
{
	my ($option, $value) = @_;
	open(CONF, "</etc/f-prot.conf") || die("Cannot open /etc/f-prot.conf: $!\n Cannot continue\n\n");
	my @conf = <CONF>;
	close(CONF);
	foreach (@conf){
		s/^\s*$option\s*=.*/$option=\"$value\"\n/;
	}
	if( ! grep($option, @conf)){
		push @conf, "$option=\"$value\"\n";
	}
	open(CONF, ">/etc/f-prot.conf") || die("Cannot open /etc/f-prot.conf: $!\n Cannot continue\n\n");
	print CONF @conf;
	close(CONF);
}

sub findDir
{
	foreach (@_){
		return $_ if  -e $_;
	}
	return undef;
}


eval {
	local $ENV{PERL_RL} = "Gnu";
	require Term::ReadLine;

	# If we haven't failed the require already
	unless (exists $INC{"Term/ReadLine/Gnu.pm"}) {
		# Term::ReadLine::Perl doesn't seem to handle tab completion
		# properly, `/tm<TAB>' will result in `/tmp/@ ' and `/va<TAB>'
		# will result in `/var/ ` (note the space) so to complete into
		# `/var/spool' the user first has to erase that single space.
		# For that reason require Term::ReadLine::Gnu and reject
		# Term::ReadLine::Perl
		die "Don't have Term::ReadLine::Gnu installed, failing";
	}
};
if ($@) {
	*Term::ReadLine::ornaments = sub {};
	*Term::ReadLine::new = sub { bless [] => shift };
	*Term::ReadLine::readline = sub
	{
		my ($self, $prompt) = @_;
		print $prompt;
		if (defined(my $line = <STDIN>)) {
			chomp $line;
			return $line;
		} else {
			# Don't have any input
			return undef;
		}
	}

}

sub Question
{
	my ($question,$default) = @_;
	my $answer;
	my $term = Term::ReadLine->new("F-Prot Installer");
	$term->ornaments('ul');
	my $prompt = "\n$question?";

	if (@_ > 1) {
		# Provide a default choice if passed two params
		$prompt .= "\n(Just press Enter to accept the default) [$default]: ";
	} else {
		# ugh formatting
		$prompt .= ": ";
	}

	$answer = $term->readline("$prompt");
	return $default if $answer eq "";
	die "Quitting! \n" if $answer eq "q" or $answer eq "Q";
	return $answer;
}

sub makeScript
{
	my ($scriptname, $contents) = @_;
	if( -e $scriptname )
	{
		print "\nFile $scriptname already exists.\n";
		if( (my $reply=Question("Replace it with a wrapper script?", "Y/n")) =~ /^y/i )
		{
			if( ! unlink($scriptname) )
			{
				die("\nCannot remove $scriptname: $!\n Please investigate and then re-run this script\n\n");
			}
		}
	}
	open SCRIPT, ">".$scriptname or die "Could not create file $scriptname.\n".$!;
	print SCRIPT $contents;
	close SCRIPT;
	chmod 0755,$scriptname;
	return;
}

sub createFpscanScript
{
	my $fpscan = shift;
	# default should work for most shells
	my $script = "#!$SHELL\nFPSCAN=\"".$fpscan."\"\n\$FPSCAN \"\$\@\"\n";

	# csh has requires special attention
	if($SHELL =~ m/csh/)
	{
		$script = "#!$SHELL\nset FPSCAN=\"".$fpscan."\"\n\$FPSCAN \$argv:q\n";
	}
	return $script;
}

main();
